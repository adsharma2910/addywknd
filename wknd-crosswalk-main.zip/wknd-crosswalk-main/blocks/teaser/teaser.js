/**
 * @param {HTMLElement} $block
 */
export default function decorate() {

}
